

import java.io.IOException;

import javax.swing.*;

public class UserInterface {
    
    public static void main(String args[]) throws IOException{
        JFrame frame = new JFrame("Time Punch app");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        int oneD = 300;
        frame.setSize(oneD, oneD);
        JButton startButton = new JButton("Start");
        startButton.setToolTipText("Push this button to Punch in");
        JButton stopButton = new JButton("Stop");
        stopButton.setToolTipText("Push this button to Punch out");
        startButton.setBounds(25, 150, oneD / 4, oneD / 10);
        stopButton.setBounds(oneD - 25, 150, oneD / 4, oneD / 10);
        frame.getContentPane().add(startButton);
        frame.getContentPane().add(stopButton);
        frame.setLayout(null);
        frame.setVisible(true);
    }
}
